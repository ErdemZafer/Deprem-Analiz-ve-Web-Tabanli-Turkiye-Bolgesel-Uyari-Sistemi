from flask import Flask, render_template, request, redirect, url_for, flash
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, Length, EqualTo
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'cok_gizli_anahtar_buraya' # Bu anahtarı gerçek bir değerle değiştir!
                                                    # Güvenlik için rastgele bir string kullan.

# E-posta adreslerinin kaydedileceği dosya yolu
# Bu yolu MATLAB kodundaki dosya yolu ile aynı yapmalısın.
EMAIL_FILE = os.path.join(os.path.expanduser("~"), 'Desktop', 'YeniMetinBelgesi.txt')

# Klasör ve dosya var mı kontrol et, yoksa oluştur
if not os.path.exists(os.path.dirname(EMAIL_FILE)):
    os.makedirs(os.path.dirname(EMAIL_FILE))
if not os.path.exists(EMAIL_FILE):
    with open(EMAIL_FILE, 'w') as f:
        pass # Dosyayı oluştur

# Kayıt Formu Tanımlaması
class RegistrationForm(FlaskForm):
    email = StringField('E-posta', validators=[DataRequired(), Email()])
    password = PasswordField('Şifre', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Şifreyi Onayla', validators=[DataRequired(), EqualTo('password', message='Şifreler eşleşmiyor!')])
    submit = SubmitField('Kaydol')

@app.route('/')
@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        user_email = form.email.data
        user_password = form.password.data # Şifreyi doğrudan kaydetmiyoruz, sadece web sitesi girişi için kullanabiliriz.
                                         # E-posta adresini kaydediyoruz.

        # E-posta adresini dosyaya kaydet
        try:
            with open(EMAIL_FILE, 'a') as f: # 'a' (append) modu dosyaya ekleme yapar
                f.write(user_email + '\n')
            flash('Kaydınız başarıyla oluşturuldu! E-posta adresiniz listeye eklendi.', 'success')
            return redirect(url_for('success'))
        except IOError as e:
            flash(f'E-posta adresi kaydedilirken bir hata oluştu: {e}', 'danger')
            app.logger.error(f"Dosyaya yazma hatası: {e}") # Hata günlüğüne kaydet
    return render_template('register.html', title='Kayıt Ol', form=form)

@app.route('/success')
def success():
    return render_template('success.html', title='Başarılı')

if __name__ == '__main__':
    # Sadece bu bilgisayarda çalışması için host ayarını '0.0.0.0' yapabilirsin.
    # Bu, yerel ağdaki diğer cihazların da erişmesine izin verir.
    # Eğer sadece kendi bilgisayarından erişmek istiyorsan '127.0.0.1' (localhost) kullan.
    app.run(debug=True, host='0.0.0.0', port=5000)